
export default function Home(){
    return <h1>Aluno: Matheus Zanivan Andrade | BCC</h1>;
}